
import os
from flask import Flask, request
import requests

app = Flask(__name__)

BOT_TOKEN = os.environ.get("BOT_TOKEN")
BLENDER_API_URL = os.environ.get("BLENDER_API_URL")

@app.route('/webhook', methods=['POST'])
def webhook():
    data = request.json
    if 'message' in data:
        chat_id = data['message']['chat']['id']
        if 'text' in data['message']:
            text = data['message']['text']
            if text == '/start':
                send_message(chat_id, "سلام! به ربات مدل‌سازی سه‌بعدی خوش آمدید.")
            elif text.startswith("مدل بساز"):
                send_message(chat_id, "در حال ساخت مدل...")
                requests.post(f"{BLENDER_API_URL}/create", json={"description": "simple model"})
                send_message(chat_id, "مدل ساخته شد!")
            else:
                send_message(chat_id, "دستور ناشناخته است.")
    return 'ok'

def send_message(chat_id, text):
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
    requests.post(url, json={"chat_id": chat_id, "text": text})

@app.route('/')
def home():
    return 'Doji Bot is running!'

if __name__ == '__main__':
    app.run(debug=True)
